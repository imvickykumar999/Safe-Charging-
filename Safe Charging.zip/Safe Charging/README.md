Write "python run.py" in address bar, hit enter.

https://github.com/imvickykumar999/Safe-Charging-/archive/master.zip