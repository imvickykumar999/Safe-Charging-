import os, sys
def resource_path(relative_path):
    try:
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")
    return os.path.join(base_path, relative_path)
script = resource_path('dist\\safebattery\\PyQt5\\Qt\\translations')
os.chdir(script) 
os.system('pip install -r requirements.txt')
os.system('python safebattery.py')